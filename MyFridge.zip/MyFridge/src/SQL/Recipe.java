package SQL;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Recipe implements Serializable {
	private static final long serialVersionUID = 1L;
	private String name;
	private String url;
	private String imageUrl;
	private float calories;
	private ArrayList<String> ingredients = new ArrayList<String>();
	private ArrayList<String> dietLabels = new ArrayList<String>();
	private ArrayList<String> healthLabels = new ArrayList<String>();
	
	//constructors
	public Recipe(String name, String url, String imageUrl, float calories,
			ArrayList<String> ingredients, ArrayList<String> dietLabels,ArrayList<String> healthLabels) {
		this.name=name;
		this.url=url;
		this.imageUrl=imageUrl;
		this.calories=calories;
		this.ingredients=ingredients;
		this.dietLabels=dietLabels;
		this.healthLabels=healthLabels;
	}
	
	public Recipe() {
		
	}
	
	//custom methods
	public void addIngredient(String s) {
		ingredients.add(s);
	}
	public void removeIngredient(String s) {
		ingredients.removeAll(Collections.singleton(s));
	}
	public void addDietLabel(String s) {
		dietLabels.add(s);
	}
	public void removeDietLabel(String s) {
		dietLabels.removeAll(Collections.singleton(s));
	}
	public void addHealthLabel(String s) {
		healthLabels.add(s);
	}
	public void removeHealthLabel(String s) {
		healthLabels.removeAll(Collections.singleton(s));
	}
	
		
	//getters & setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public float getCalories() {
		return calories;
	}
	public void setCalories(float calories) {
		this.calories = calories;
	}
	public ArrayList<String> getIngredients() {
		return ingredients;
	}
	public void setIngredients(ArrayList<String> ingredients) {
		this.ingredients = ingredients;
	}
	public ArrayList<String> getDietLabels() {
		return dietLabels;
	}
	public void setDietLabels(ArrayList<String> dietLabels) {
		this.dietLabels = dietLabels;
	}
	public ArrayList<String> getHealthLabels() {
		return healthLabels;
	}
	public void setHealthLabels(ArrayList<String> healthLabels) {
		this.healthLabels = healthLabels;
	}

}
