package SQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.util.Collections;
import java.util.Vector;

public class JDBC {

	/* [--------COMPLETE--------] */
	public String validation(String u, String p) {
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MyFridge?user=root&password=root");
			ps = conn.prepareStatement("SELECT * FROM Users WHERE username=? AND password=?");
			ps.setString(1,  u); //specifies that first ? should be the fname from request
			ps.setString(2, p);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				return "success";
			}
			else {
				rs.close();
				ps.close();
				conn.close();
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MyFridge?user=root&password=root");
				ps = conn.prepareStatement("SELECT * FROM Users WHERE username=?");
				ps.setString(1,  u); //specifies that first ? should be the fname from request
				rs = ps.executeQuery();
				
				if(rs.next()) {
					return "Incorrect Password";
				}
				else {
					return "Username Does Not Exist";
				}
			}
			
		} catch(SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} catch(ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		} finally {
			try {
				if(rs != null) {
					rs.close();
				}
				if(ps != null) {
					ps.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch(SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		return "";
		
	}
	
	/* [--------COMPLETE--------] */
	public String addCustomRecipe(String u, String rn, String ing, String st) {
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		if(rn == null || rn == "" || ing == null || ing == "" || st == null || st == "") {
			return "Invaild Input Values";
		}
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MyFridge?user=root&password=root");
			Statement s = conn.createStatement();
			s.executeUpdate("INSERT INTO CustomRecipes(username,recipeName,ingredients,steps) VALUES ('" + u + "','" + rn  + "','" + ing  + "','" + st + "');");
			
		} catch(SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} catch(ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		} finally {
			try {
				if(rs != null) {
					rs.close();
				}
				if(ps != null) {
					ps.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch(SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		return "success";
		
	}
	
	/* [--------COMPLETE--------] */
	public String registerUser(String u, String p1, String p2) {
		
		/*if(!p1.equals(p2)) {
			return "Passwords Do Not Match";
		}
		
		if(u.length() <= 4) {
			return "Username Must Be Longer Than 4 Characters";
		}
		
		if(p1.length() < 8) {
			return "Password Must Be At Least 8 Characters";
		}*/
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null; //stores the table returned by SELECT
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MyFridge?user=root&password=root");
			ps = conn.prepareStatement("SELECT * FROM Users WHERE username=?");
			ps.setString(1,  u); //specifies that first ? should be the fname from request
			rs = ps.executeQuery();
			
			if(rs.next()) {
				rs.close();
				ps.close();
				conn.close();
				return "Username Already Exists";
			}
			else {
				rs.close();
				ps.close();
				conn.close();
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MyFridge?user=root&password=root");
				Statement s = conn.createStatement();
				s.executeUpdate("INSERT INTO Users(username,password) VALUES ('" + u + "','" + p1 + "');");
			}
			
		} catch(SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} catch(ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		} finally {
			try {
				if(rs != null) {
					rs.close();
				}
				if(ps != null) {
					ps.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch(SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		return "success";
		
	}
	
	/* [--------COMPLETE--------]
	 * returns a Vector where each String is a recipe:
	 * 		Each component (name, steps) is separated with "|",
	 * 		each step / ingredient should be separated with "/" by user */
	public Vector<String> getCustomRecipes(String u) {
		
		Vector<String> v = new Vector<String>();
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null; //stores the table returned by SELECT
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MyFridge?user=root&password=root");
			ps = conn.prepareStatement("SELECT * FROM CustomRecipes WHERE username=?");
			ps.setString(1,  u);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				String recipe = "" + rs.getString("recipeName") + "|" + rs.getString("ingredients") + "|" + rs.getString("steps");
				
				if(recipe != null) {
					v.add(recipe);
				}
				
			}
			
		} catch(SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} catch(ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		} finally {
			try {
				if(rs != null) {
					rs.close();
				}
				if(ps != null) {
					ps.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch(SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		return v;
		
	}
	
	
	public void addIngredient(String u, String ing) {
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MyFridge?user=root&password=root");
			Statement s = conn.createStatement();
			
			//GOTTA ACCOUNT FOR IF INGREDIENT ALREADY EXISTS
			s.executeUpdate("INSERT INTO Ingredients(username,ingredientName) VALUES ('" + u + "','" + ing + ")");
			
		} catch(SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} catch(ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		} finally {
			try {
				if(rs != null) {
					rs.close();
				}
				if(ps != null) {
					ps.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch(SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
	}
	
	public Vector<String> getIngredients(String u) {
		
		Vector<String> v = new Vector<String>();
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null; //stores the table returned by SELECT
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MyFridge?user=root&password=root");
			ps = conn.prepareStatement("SELECT * FROM Ingredients WHERE username=?");
			ps.setString(1,  u);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				String ing = rs.getString("ingredientName");
				
				if(ing != null) {
					v.add(ing);
				}
				
			}
			
		} catch(SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} catch(ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		} finally {
			try {
				if(rs != null) {
					rs.close();
				}
				if(ps != null) {
					ps.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch(SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		return v;
		
	}
	
}
