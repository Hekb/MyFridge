package Servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.FoodAPI.FoodAPI;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Servlet implementation class ParseSearch
 */
@WebServlet("/ParseSearch")
public class ParseSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String food = request.getParameter("food");
		System.out.println(food);
		food = food.replace(' ', '-');
		
		String targetPage = "/results.jsp";
		
		URL url = new URL("https://api.edamam.com/search?q=" + food + "&app_id=278bbd02&app_key=7d60a3510c6faa58ff3b27f73e5b120e");
		BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
		
		URLConnection uc = url.openConnection();
		uc.connect();
		
		JsonParser jp = new JsonParser();
		JsonElement root = jp.parse(new InputStreamReader((InputStream) uc.getContent()));
		JsonObject rootobj = root.getAsJsonObject();
		
		Gson gson = new Gson();
		FoodAPI c = gson.fromJson(rootobj, FoodAPI.class);
		
		if(c == null) {
			targetPage = "/homepage.jsp";
			request.setAttribute("error", "No Recipes Found");
		}
		
		request.getSession(false).setAttribute("recipes", c);
		
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(targetPage);
		dispatch.forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
